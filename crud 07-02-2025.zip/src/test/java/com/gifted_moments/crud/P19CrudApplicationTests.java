package com.gifted_moments.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P19CrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
