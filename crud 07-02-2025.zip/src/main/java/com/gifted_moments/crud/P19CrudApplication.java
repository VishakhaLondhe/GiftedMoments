package com.gifted_moments.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P19CrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(P19CrudApplication.class, args);
	}

}
