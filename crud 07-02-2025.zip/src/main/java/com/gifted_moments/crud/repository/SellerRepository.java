package com.gifted_moments.crud.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gifted_moments.crud.entity.Seller;

public interface SellerRepository extends JpaRepository<Seller, Long>{

    Optional<Seller> findByUserUserId(Long userId);

}
