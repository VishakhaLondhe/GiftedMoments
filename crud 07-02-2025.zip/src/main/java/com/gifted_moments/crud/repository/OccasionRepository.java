package com.gifted_moments.crud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gifted_moments.crud.entity.Occasion;

public interface OccasionRepository extends JpaRepository<Occasion, Long> {

    boolean existsByOccasionName(String occasion);

}
