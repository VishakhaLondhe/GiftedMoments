package com.gifted_moments.crud.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gifted_moments.crud.dto.SellerTransactionDto;
import com.gifted_moments.crud.entity.Transaction;
import com.gifted_moments.crud.enums.TransactionStatus;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    Optional<Transaction> findByTransactionNo(String transactionNo);

    List<Transaction> findByOrder_OrderId(Long orderId);

    List<Transaction> findByUser_UserId(Long userId);

    List<Transaction> findByStatus(TransactionStatus status);

    void deleteByOrderOrderId(Long orderId);

    @Query("SELECT new com.gifted_moments.crud.dto.SellerTransactionDto( " +
            "t.transactionId, t.transactionNo, t.transactionDate,t.user, t.status, t.paymentMode,SUM(oi.price * oi.quantity)) " +
            "FROM Transaction t " +
            "JOIN t.order o " +
            "JOIN o.orderItems oi " +
            "JOIN oi.sellerProduct sp " +
            "JOIN sp.seller s " +
            "WHERE s.sellerId = :sellerId " +
            "GROUP BY t.transactionId, t.transactionNo, t.transactionDate, t.status")
    List<SellerTransactionDto> findTransactionsBySellerId(@Param("sellerId") Long sellerId);

}
