package com.gifted_moments.crud.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gifted_moments.crud.entity.Order;
import com.gifted_moments.crud.enums.OrderStatus;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserUserId(Long userId);

 
    List<Order> findByStatus(OrderStatus status);
}
