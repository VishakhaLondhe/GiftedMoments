package com.gifted_moments.crud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gifted_moments.crud.entity.Customization;

public interface CustomizationRepository extends JpaRepository<Customization, Long>{

}
