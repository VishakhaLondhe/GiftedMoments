package com.gifted_moments.crud.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gifted_moments.crud.entity.SellerProduct;
import com.gifted_moments.crud.entity.UserRating;

public interface UserRatingRepository extends JpaRepository<UserRating, Long> {
    List<UserRating> findBySellerProduct_SellerProductId(Long sellerProductId);

    List<UserRating> findByUser_UserId(Long userId);

    @Query("SELECT ur.sellerProduct FROM UserRating ur WHERE ur.rating >= :rating GROUP BY ur.sellerProduct")
    List<SellerProduct> findSellerProductsWithMinimumRating(@Param("rating") int rating);

    List<UserRating> findBySellerProduct_SellerProductIdOrderByDateTimeDesc(Long sellerProductId);
    
    List<UserRating> findByUser_UserIdOrderByDateTimeDesc(Long userId);
}
