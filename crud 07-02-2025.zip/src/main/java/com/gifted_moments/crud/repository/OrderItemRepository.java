package com.gifted_moments.crud.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.gifted_moments.crud.entity.OrderItem;
import com.gifted_moments.crud.entity.SellerProduct;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {
    List<OrderItem> findBySellerProduct_SellerProductId(Long sellerProductId);
    
    List<OrderItem> findByProduct_ProductId(Long productId);

    List<OrderItem> findBySellerProductSellerSellerId(@Param("sellerId") Long sellerId);
}
