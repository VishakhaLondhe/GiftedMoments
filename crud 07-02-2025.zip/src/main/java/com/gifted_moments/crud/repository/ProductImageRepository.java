package com.gifted_moments.crud.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gifted_moments.crud.entity.ProductImage;

public interface ProductImageRepository extends JpaRepository<ProductImage, Long> {

    List<ProductImage> findBySellerProductSellerProductId(Long productId);

}
