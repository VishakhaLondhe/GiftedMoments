package com.gifted_moments.crud.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.gifted_moments.crud.entity.User;
import com.gifted_moments.crud.enums.PaymentMode;
import com.gifted_moments.crud.enums.TransactionStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class SellerTransactionDto {
    private Long transactionId;
    private String transactionNo;
    private LocalDateTime transactionDate;
    private User user;
    private TransactionStatus status;
    private PaymentMode paymentMode;
    private BigDecimal totalRevenue;
}
