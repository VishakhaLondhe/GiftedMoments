package com.gifted_moments.crud.dto;

import java.math.BigDecimal;

import com.gifted_moments.crud.entity.Customization;
import com.gifted_moments.crud.entity.OrderItem;

import lombok.Data;

@Data
public class OrderItemDto {
    private Long orderItemId;
    private SellerProductDto sellerProduct;
    private int quantity;
    private BigDecimal price;
    private BigDecimal totalPrice;
    private Customization customization;

    public static OrderItemDto fromOrderItem(OrderItem orderItem) {
        OrderItemDto orderItemDto = new OrderItemDto();
        orderItemDto.setOrderItemId(orderItem.getOrderItemId());
        orderItemDto.setSellerProduct(SellerProductDto.fromSellerProduct(orderItem.getSellerProduct()));
        orderItemDto.setQuantity(orderItem.getQuantity());
        orderItemDto.setPrice(orderItem.getPrice());
        orderItemDto.setTotalPrice(orderItem.getTotalPrice());
        orderItemDto.setCustomization(orderItem.getCustomization());
        return orderItemDto;
    }
}
