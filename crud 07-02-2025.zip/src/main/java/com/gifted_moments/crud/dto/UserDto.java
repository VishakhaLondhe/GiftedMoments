package com.gifted_moments.crud.dto;

import com.gifted_moments.crud.entity.Role;
import com.gifted_moments.crud.entity.User;

import lombok.Data;

@Data
public class UserDto {
    private Long userId;
    private String userName;
    private String emailId;
    private String password;
    private String contactNo;
    private String address;
    private Role role;

    private Long sellerId;

    public static UserDto fromUser(User user) {
        UserDto userDto = new UserDto();
        userDto.setUserId(user.getUserId());
        userDto.setUserName(user.getUserName());
        userDto.setEmailId(user.getEmailId());
        userDto.setPassword(user.getPassword());
        userDto.setContactNo(user.getContactNo());
        userDto.setAddress(user.getAddress());
        userDto.setRole(user.getRole());
        return userDto;
    }
}
