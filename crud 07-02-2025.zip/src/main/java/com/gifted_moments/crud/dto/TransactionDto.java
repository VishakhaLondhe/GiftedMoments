package com.gifted_moments.crud.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.gifted_moments.crud.entity.Transaction;
import com.gifted_moments.crud.enums.PaymentMode;
import com.gifted_moments.crud.enums.TransactionStatus;

import lombok.Data;

@Data
public class TransactionDto {
    private Long transactionId;
    private String transactionNo;
    private OrderDto order;
    private UserDto user;
    private LocalDateTime transactionDate;
    private BigDecimal transactionAmount;
    private PaymentMode paymentMode;
    private TransactionStatus status;


    public static TransactionDto fromTransaction(Transaction transaction) {
        TransactionDto transactionDto = new TransactionDto();
        transactionDto.setTransactionId(transaction.getTransactionId());
        transactionDto.setTransactionNo(transaction.getTransactionNo());
        transactionDto.setOrder(OrderDto.fromOrder(transaction.getOrder()));
        transactionDto.setUser(UserDto.fromUser(transaction.getUser()));
        transactionDto.setTransactionDate(transaction.getTransactionDate());
        transactionDto.setTransactionAmount(transaction.getTransactionAmount());
        transactionDto.setPaymentMode(transaction.getPaymentMode());
        transactionDto.setStatus(transaction.getStatus());
        return transactionDto;
    }
}
