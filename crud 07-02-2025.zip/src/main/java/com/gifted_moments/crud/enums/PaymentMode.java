package com.gifted_moments.crud.enums;

public enum PaymentMode {
    CASH,
    CARD,
    NET_BANKING,
    COD,
    UPI
}
