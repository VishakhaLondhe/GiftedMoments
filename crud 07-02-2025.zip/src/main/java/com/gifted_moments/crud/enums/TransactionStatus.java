package com.gifted_moments.crud.enums;

public enum TransactionStatus {
    PENDING,
    FAILED,
    COMPLETED
}
