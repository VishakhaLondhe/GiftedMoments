package com.gifted_moments.crud.request;

import lombok.Data;

@Data
public class BasicInfoRequest {
    private String name;
    private String description;
}
