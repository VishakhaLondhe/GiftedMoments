package com.gifted_moments.crud.request;

import java.math.BigDecimal;
import com.gifted_moments.crud.enums.PaymentMode;

import lombok.Data;

@Data
public class TransactionRequest {

    private Long orderId;

    private Long userId;


    private BigDecimal transactionAmount;

    private PaymentMode paymentMode;
}
