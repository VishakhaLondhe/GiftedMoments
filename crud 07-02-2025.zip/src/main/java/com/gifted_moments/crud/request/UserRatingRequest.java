package com.gifted_moments.crud.request;

import java.time.LocalDateTime;

import lombok.Data;


@Data
public class UserRatingRequest {
    private Long ratingId;
    
    private int rating;
    private String review;
    private LocalDateTime dateTime;

    private Long userId;
    private Long sellerProductId;
}
