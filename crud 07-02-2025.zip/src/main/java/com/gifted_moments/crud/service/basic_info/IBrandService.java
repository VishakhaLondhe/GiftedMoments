package com.gifted_moments.crud.service.basic_info;

import java.util.List;

import com.gifted_moments.crud.entity.Brand;
import com.gifted_moments.crud.request.BasicInfoRequest;

public interface IBrandService {
    Brand createBrand(BasicInfoRequest basicInfoRequest);
    Brand updateBrand(Long brandId, BasicInfoRequest basicInfoRequest);
    void deleteBrand(Long brandId);
    List<Brand> getAllBrands();
}
