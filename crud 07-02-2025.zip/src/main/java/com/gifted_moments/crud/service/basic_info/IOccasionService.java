package com.gifted_moments.crud.service.basic_info;

import java.util.List;

import com.gifted_moments.crud.dto.OccasionDto;
import com.gifted_moments.crud.request.BasicInfoRequest;

public interface IOccasionService {
    OccasionDto createOccasion(BasicInfoRequest basicInfoRequest);

    OccasionDto updateOccasion(Long occasionId, BasicInfoRequest basicInfoRequest);

    void deleteOccasion(Long occasionId);

    List<OccasionDto> getAllOccasions();
}
