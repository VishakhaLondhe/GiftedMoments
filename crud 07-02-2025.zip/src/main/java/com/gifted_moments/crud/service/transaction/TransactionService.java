package com.gifted_moments.crud.service.transaction;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gifted_moments.crud.dto.SellerTransactionDto;
import com.gifted_moments.crud.dto.TransactionDto;
import com.gifted_moments.crud.entity.Transaction;
import com.gifted_moments.crud.enums.TransactionStatus;
import com.gifted_moments.crud.repository.OrderRepository;
import com.gifted_moments.crud.repository.TransactionRepository;
import com.gifted_moments.crud.repository.UserRepository;
import com.gifted_moments.crud.request.TransactionRequest;
import com.gifted_moments.crud.util.Constants;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TransactionService implements ITransactionService {
    private final TransactionRepository transactionRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;

    @Transactional
    @Override
    public TransactionDto createTransaction(TransactionRequest request) {
        Transaction transaction = new Transaction();
        transaction.setTransactionNo(generateTransactionNo());
        transaction.setOrder(orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new EntityNotFoundException("Order not found")));
        transaction.setUser(
                userRepository.findById(request.getUserId())
                        .orElseThrow(() -> new EntityNotFoundException(Constants.USER_NOT_FOUND)));
        transaction.setTransactionDate(LocalDateTime.now());
        transaction.setTransactionAmount(request.getTransactionAmount());
        transaction.setPaymentMode(request.getPaymentMode());
        transaction.setStatus(TransactionStatus.PENDING);

        transaction = transactionRepository.save(transaction);

        return TransactionDto.fromTransaction(transaction);
    }

    @Transactional
    @Override
    public TransactionDto updateTransaction(Long transactionId, TransactionRequest request) {
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.TRANSACTION_NOT_FOUND));

        transaction.setOrder(orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new EntityNotFoundException("Order not found")));
        transaction.setUser(
                userRepository.findById(request.getUserId())
                        .orElseThrow(() -> new EntityNotFoundException(Constants.USER_NOT_FOUND)));
        transaction.setTransactionAmount(request.getTransactionAmount());
        transaction.setPaymentMode(request.getPaymentMode());

        transaction = transactionRepository.save(transaction);
        return TransactionDto.fromTransaction(transaction);
    }

    @Transactional
    @Override
    public void deleteTransaction(Long transactionId) {
        if (!transactionRepository.existsById(transactionId)) {
            throw new EntityNotFoundException(Constants.TRANSACTION_NOT_FOUND);
        }
        transactionRepository.deleteById(transactionId);
    }

    @Override
    public TransactionDto getTransactionById(Long transactionId) {
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.TRANSACTION_NOT_FOUND));
        return TransactionDto.fromTransaction(transaction);
    }

    @Override
    public List<TransactionDto> getTransactionsByOrderId(Long orderId) {
        return transactionRepository.findByOrder_OrderId(orderId)
                .stream().map(TransactionDto::fromTransaction).toList();
    }

    @Override
    public List<TransactionDto> getTransactionsByUserId(Long userId) {
        return transactionRepository.findByUser_UserId(userId)
                .stream().map(TransactionDto::fromTransaction).toList();
    }

    @Override
    public TransactionDto getTransactionByTransactionNo(String transactionNo) {
        Transaction transaction = transactionRepository.findByTransactionNo(transactionNo)
                .orElseThrow(() -> new EntityNotFoundException(Constants.TRANSACTION_NOT_FOUND));
        return TransactionDto.fromTransaction(transaction);
    }

    @Override
    public List<SellerTransactionDto> getTransactionBySellerId(Long sellerId) {
        return transactionRepository.findTransactionsBySellerId(sellerId);
    }

    @Override
    public List<TransactionDto> getTransactionsByStatus(TransactionStatus status) {
        return transactionRepository.findByStatus(status)
                .stream().map(TransactionDto::fromTransaction).toList();
    }

    private String generateTransactionNo() {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (int i = 0; i < 12; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    @Override
    public List<TransactionDto> getAllTransactions() {
        return transactionRepository.findAll()
                .stream().map(TransactionDto::fromTransaction).toList();
    }
}
