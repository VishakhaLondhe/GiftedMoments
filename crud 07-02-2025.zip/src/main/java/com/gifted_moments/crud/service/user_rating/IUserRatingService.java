package com.gifted_moments.crud.service.user_rating;

import java.util.List;

import com.gifted_moments.crud.dto.SellerProductDto;
import com.gifted_moments.crud.dto.UserRatingDto;
import com.gifted_moments.crud.request.UserRatingRequest;

public interface IUserRatingService {

    UserRatingDto createUserRating(UserRatingRequest userRatingRequest);

    UserRatingDto updateUserRating(Long ratingId, UserRatingRequest userRatingRequest);

    void deleteUserRating(Long ratingId);

    List<UserRatingDto> getAllUserRatings();

    UserRatingDto getUserRatingById(Long ratingId);

    List<UserRatingDto> getUserRatingsBySellerProductId(Long sellerProductId);

    List<UserRatingDto> getUserRatingsByUserId(Long userId);

    List<SellerProductDto> getSellerProductsByMinimumRating(int rating);

}
