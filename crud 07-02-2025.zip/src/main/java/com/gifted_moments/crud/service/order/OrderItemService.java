package com.gifted_moments.crud.service.order;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gifted_moments.crud.dto.OrderItemDto;
import com.gifted_moments.crud.dto.SellerProductDto;
import com.gifted_moments.crud.entity.Customization;
import com.gifted_moments.crud.entity.Order;
import com.gifted_moments.crud.entity.OrderItem;
import com.gifted_moments.crud.entity.Product;
import com.gifted_moments.crud.entity.SellerProduct;
import com.gifted_moments.crud.repository.CustomizationRepository;
import com.gifted_moments.crud.repository.OrderItemRepository;
import com.gifted_moments.crud.repository.OrderRepository;
import com.gifted_moments.crud.repository.ProductRepository;
import com.gifted_moments.crud.repository.SellerProductRepository;
import com.gifted_moments.crud.request.OrderItemRequest;
import com.gifted_moments.crud.util.Constants;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderItemService implements IOrderItemService {
    private final OrderItemRepository orderItemRepository;
    private final ProductRepository productRepository;
    private final SellerProductRepository sellerProductRepository;
    private final OrderRepository orderRepository;
    private final CustomizationRepository customizationRepository;

    @Override
    public OrderItemDto createOrderItem(OrderItemRequest orderItemRequest) {
        // Product product = productRepository.findById(orderItemRequest.getProductId())
        //         .orElseThrow(() -> new EntityNotFoundException("Product not found"));

        SellerProduct sellerProduct = sellerProductRepository.findById(orderItemRequest.getSellerProductId())
                .orElseThrow(() -> new EntityNotFoundException("Seller Product not found"));

        Order order = orderRepository.findById(orderItemRequest.getOrderId())
                .orElseThrow(() -> new EntityNotFoundException("Order not found"));

        Customization customization = null;
        if (orderItemRequest.getCustomization() != null) {
            customization = customizationRepository.save(orderItemRequest.getCustomization());
        }

        if (orderItemRequest.getQuantity() <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than 0");
        }
        if (orderItemRequest.getQuantity() > sellerProduct.getProductQuantity()) {
            throw new IllegalArgumentException("Quantity must be less than available product ");
        }

        BigDecimal totalPrice = sellerProduct.getProductPrice()
                .multiply(BigDecimal.valueOf(orderItemRequest.getQuantity()));

        OrderItem orderItem = new OrderItem();
        // orderItem.setProduct(product);
        orderItem.setProduct(sellerProduct.getProduct());
        orderItem.setSellerProduct(sellerProduct);
        orderItem.setOrder(order);
        orderItem.setQuantity(orderItemRequest.getQuantity());
        orderItem.setPrice(sellerProduct.getProductPrice());
        orderItem.setTotalPrice(totalPrice);
        orderItem.setCustomization(customization);

        sellerProduct.setProductQuantity(sellerProduct.getProductQuantity() - orderItemRequest.getQuantity());

        sellerProductRepository.save(sellerProduct);
        OrderItem savedOrderItem = orderItemRepository.save(orderItem);
        return OrderItemDto.fromOrderItem(savedOrderItem);
    }

    @Override
    public OrderItemDto createOrderItemByOrderId(Long orderId, OrderItemRequest orderItemRequest) {
        orderItemRequest.setOrderId(orderId);
        return createOrderItem(orderItemRequest);
    }

    @Override
    public OrderItemDto updateOrderItem(Long orderItemId, OrderItemRequest orderItemRequest) {

        OrderItem orderItem = orderItemRepository.findById(orderItemId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.ORDER_ITEM_NOT_FOUND));

        if (orderItemRequest.getQuantity() <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than 0");
        }

        SellerProduct sellerProduct = orderItem.getSellerProduct();
        if (sellerProduct == null) {
            throw new EntityNotFoundException("SellerProduct not found for OrderItem ID " + orderItemId);
        }

        BigDecimal totalPrice = sellerProduct.getProductPrice()
                .multiply(BigDecimal.valueOf(orderItemRequest.getQuantity()));

        orderItem.setQuantity(orderItemRequest.getQuantity());
        orderItem.setPrice(sellerProduct.getProductPrice());
        orderItem.setTotalPrice(totalPrice);

        int quantityDifference = orderItemRequest.getQuantity() - orderItem.getQuantity();
        sellerProduct.setProductQuantity(sellerProduct.getProductQuantity() - quantityDifference);

        if (sellerProduct.getProductQuantity() < 0) {
            throw new IllegalArgumentException("Not enough stock for the SellerProduct.");
        }

        sellerProductRepository.save(sellerProduct);
        OrderItem updatedOrderItem = orderItemRepository.save(orderItem);

        return OrderItemDto.fromOrderItem(updatedOrderItem);
    }

    @Override
    public void deleteOrderItem(Long orderItemId) {
        if (!orderItemRepository.existsById(orderItemId)) {
            throw new EntityNotFoundException(Constants.ORDER_ITEM_NOT_FOUND);
        }
        orderItemRepository.deleteById(orderItemId);
    }

    @Override
    public List<OrderItemDto> getAllOrderItems() {
        return orderItemRepository.findAll()
                .stream()
                .map(OrderItemDto::fromOrderItem)
                .toList();
    }

    @Override
    public OrderItemDto getOrderItemById(Long orderItemId) {
        OrderItem orderItem = orderItemRepository.findById(orderItemId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.ORDER_ITEM_NOT_FOUND));
        return OrderItemDto.fromOrderItem(orderItem);
    }

    @Override
    public List<OrderItemDto> getOrderItemsBySellerProductId(Long sellerProductId) {
        return orderItemRepository.findBySellerProduct_SellerProductId(sellerProductId)
                .stream()
                .map(OrderItemDto::fromOrderItem)
                .toList();
    }

    @Override
    public List<OrderItemDto> getOrderItemsByProductId(Long productId) {
        return orderItemRepository.findByProduct_ProductId(productId)
                .stream()
                .map(OrderItemDto::fromOrderItem)
                .toList();
    }

    @Override
    public List<OrderItemDto> getSellerProductsBySellerId(Long sellerId) {
        List<OrderItem> sellerProducts = orderItemRepository.findBySellerProductSellerSellerId(sellerId);
        return sellerProducts.stream().map(OrderItemDto::fromOrderItem).toList();
    }
}
