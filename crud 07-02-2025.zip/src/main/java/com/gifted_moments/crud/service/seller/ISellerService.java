package com.gifted_moments.crud.service.seller;

import java.util.List;

import com.gifted_moments.crud.dto.SellerDto;
import com.gifted_moments.crud.entity.Seller;
import com.gifted_moments.crud.request.SellerRequest;



public interface ISellerService {
    SellerDto createSeller(Seller seller);
    SellerDto updateSeller(Long sellerId, SellerRequest seller);
    void deleteSeller(Long sellerId);
    SellerDto getSellerById(Long sellerId);
    SellerDto getSellerByUserId(Long userId);
    List<SellerDto> getAllSellers();
}
