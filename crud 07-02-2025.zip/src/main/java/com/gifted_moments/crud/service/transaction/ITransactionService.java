package com.gifted_moments.crud.service.transaction;

import java.util.List;

import com.gifted_moments.crud.dto.SellerTransactionDto;
import com.gifted_moments.crud.dto.TransactionDto;
import com.gifted_moments.crud.enums.TransactionStatus;
import com.gifted_moments.crud.request.TransactionRequest;

public interface ITransactionService {
    TransactionDto createTransaction(TransactionRequest request);
    TransactionDto updateTransaction(Long transactionId, TransactionRequest request);
    void deleteTransaction(Long transactionId);
    TransactionDto getTransactionById(Long transactionId);
    List<TransactionDto> getAllTransactions();
    List<TransactionDto> getTransactionsByOrderId(Long orderId);
    List<TransactionDto> getTransactionsByUserId(Long userId);
    TransactionDto getTransactionByTransactionNo(String transactionNo);
    List<TransactionDto> getTransactionsByStatus(TransactionStatus status);
     List<SellerTransactionDto>  getTransactionBySellerId(Long sellerId);
}
