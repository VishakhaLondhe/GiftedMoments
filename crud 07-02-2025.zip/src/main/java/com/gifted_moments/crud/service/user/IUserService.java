package com.gifted_moments.crud.service.user;

import java.util.List;

import com.gifted_moments.crud.dto.UserDto;
import com.gifted_moments.crud.entity.User;



public interface IUserService {
    User createUser(User user);
    User updateUser(Long userId, User user);
    User updatePassword(Long userId, String password);
    void deleteUser(Long userId);
    User getUserById(Long userId);
    List<User> getAllUsers();
    UserDto login(String userName, String password);
}
