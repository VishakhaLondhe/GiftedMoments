package com.gifted_moments.crud.service.user_rating;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.gifted_moments.crud.dto.SellerProductDto;
import com.gifted_moments.crud.dto.UserRatingDto;
import com.gifted_moments.crud.entity.SellerProduct;
import com.gifted_moments.crud.entity.User;
import com.gifted_moments.crud.entity.UserRating;
import com.gifted_moments.crud.repository.SellerProductRepository;
import com.gifted_moments.crud.repository.UserRatingRepository;
import com.gifted_moments.crud.repository.UserRepository;
import com.gifted_moments.crud.request.UserRatingRequest;
import com.gifted_moments.crud.util.Constants;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserRatingService implements IUserRatingService {
    private final UserRatingRepository userRatingRepository;
    private final UserRepository userRepository;
    private final SellerProductRepository sellerProductRepository;

    @Override
    public UserRatingDto createUserRating(UserRatingRequest userRatingRequest) {
        User user = userRepository.findById(userRatingRequest.getUserId())
                .orElseThrow(() -> new EntityNotFoundException(Constants.USER_NOT_FOUND));

        SellerProduct sellerProduct = sellerProductRepository.findById(userRatingRequest.getSellerProductId())
                .orElseThrow(() -> new EntityNotFoundException(Constants.SELLER_PRODUCT_NOT_FOUND));

        UserRating userRating = new UserRating();
        userRating.setRating(userRatingRequest.getRating());
        userRating.setReview(userRatingRequest.getReview());
        userRating.setDateTime(LocalDateTime.now());
        userRating.setUser(user);
        userRating.setSellerProduct(sellerProduct);

        UserRating savedRating = userRatingRepository.save(userRating);
        return UserRatingDto.fromUserRating(savedRating);
    }

    @Override
    public UserRatingDto updateUserRating(Long ratingId, UserRatingRequest userRatingRequest) {
        UserRating userRating = userRatingRepository.findById(ratingId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.USER_RATING_NOT_FOUND));

        userRating.setRating(userRatingRequest.getRating());
        userRating.setReview(userRatingRequest.getReview());
        userRating.setDateTime(LocalDateTime.now());

        UserRating updatedRating = userRatingRepository.save(userRating);
        return UserRatingDto.fromUserRating(updatedRating);
    }

    @Override
    public void deleteUserRating(Long ratingId) {
        if (!userRatingRepository.existsById(ratingId)) {
            throw new EntityNotFoundException(Constants.USER_RATING_NOT_FOUND);
        }
        userRatingRepository.deleteById(ratingId);
    }

    @Override
    public UserRatingDto getUserRatingById(Long ratingId) {
        UserRating userRating = userRatingRepository.findById(ratingId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.USER_RATING_NOT_FOUND));
        return UserRatingDto.fromUserRating(userRating);
    }

 


    @Override
    public List<UserRatingDto> getAllUserRatings() {
        return userRatingRepository.findAll(Sort.by(Sort.Direction.ASC, "dateTime"))
                .stream()
                .map(UserRatingDto::fromUserRating)
                .toList();
    }


    @Override
    public List<UserRatingDto> getUserRatingsBySellerProductId(Long sellerProductId) {
        return userRatingRepository.findBySellerProduct_SellerProductIdOrderByDateTimeDesc(sellerProductId)
                .stream()
                .map(UserRatingDto::fromUserRating)
                .toList();
    }

    @Override
    public List<UserRatingDto> getUserRatingsByUserId(Long userId) {
        return userRatingRepository.findByUser_UserIdOrderByDateTimeDesc(userId)
                .stream()
                .map(UserRatingDto::fromUserRating)
                .toList();
    }

    @Override
    public List<SellerProductDto> getSellerProductsByMinimumRating(int rating) {
        List<SellerProduct> sellerProducts = userRatingRepository.findSellerProductsWithMinimumRating(rating);
        return sellerProducts.stream()
                .map(SellerProductDto::fromSellerProduct)
                .toList();
    }
}
