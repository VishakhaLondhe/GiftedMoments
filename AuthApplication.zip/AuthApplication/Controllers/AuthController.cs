﻿using AuthApplication.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AuthApplication.Controllers;

[ApiController]
[Route("[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;

    public AuthController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
    {
        var user = await _context.Users
        .Include(u => u.Role)  // Eager load the Role navigation property
        .Where(u => u.EmailId == loginModel.EmailId && u.Password == loginModel.Password)
        .Select(u => new
        {
            User = u,
            Role = u.Role
        })
        .FirstOrDefaultAsync();

        if (user?.User == null)
        {
            return Unauthorized(new { status = "error", message = "Invalid email or password" });
        }

        return Ok(
            new
            {
                status = "success",
                data = new
                {
                    userId = user.User.UserId,
                    userName = user.User.UserName,
                    emailId = user.User.EmailId,
                    password = user.User.Password,
                    contactNo = user.User.ContactNo,
                    address = user.User.Address,
                    role = user.Role != null ? new
                    {
                        roleId = user.Role.RoleId,
                        roleName = user.Role.RoleName
                    } : null,
                    sellerId = (long?)null
                }
            }
            );
    }
}

public class LoginModel
{
    public string EmailId { get; set; } = null!;
    public string Password { get; set; } = null!;
}