﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AuthApplication.Models
{
    public class Role
    {
        [Column("role_id")]
        public long RoleId { get; set; }

        [Column("role_name")]
        public string? RoleName { get; set; }

        public ICollection<User> Users { get; set; } = new List<User>();
    }
}
