﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AuthApplication.Models
{
    public class User
    {
        [Column("user_id")]
        public long UserId { get; set; }

        [Column("role_id")]
        public long? RoleId { get; set; }

        [Column("address")]
        public string? Address { get; set; }

        [Column("contact_no")]
        public string? ContactNo { get; set; }

        [Column("email_id")]
        public string EmailId { get; set; } = null!;

        [Column("password")]
        public string? Password { get; set; }

        [Column("user_name")]
        public string? UserName { get; set; }

        public Role? Role { get; set; }
    }
}
