package com.gifted_moments.transactions.service.order;

import java.util.List;

import com.gifted_moments.transactions.dto.OrderDto;
import com.gifted_moments.transactions.enums.OrderStatus;
import com.gifted_moments.transactions.request.OrderRequest;

public interface IOrderService {
    OrderDto createOrder(OrderRequest orderRequest);

    OrderDto updateOrder(Long orderId, OrderRequest orderRequest);

    void deleteOrder(Long orderId);

    List<OrderDto> getAllOrders();

    OrderDto getOrderById(Long orderId);

    List<OrderDto> getOrdersByUserId(Long userId);


    List<OrderDto> getOrdersByStatus(OrderStatus status);

}
