package com.gifted_moments.transactions.service.transaction;

import java.util.List;

import com.gifted_moments.transactions.dto.SellerTransactionDto;
import com.gifted_moments.transactions.dto.TransactionDto;
import com.gifted_moments.transactions.enums.TransactionStatus;
import com.gifted_moments.transactions.request.TransactionRequest;

public interface ITransactionService {
    TransactionDto createTransaction(TransactionRequest request);
    TransactionDto updateTransaction(Long transactionId, TransactionRequest request);
    void deleteTransaction(Long transactionId);
    TransactionDto getTransactionById(Long transactionId);
    List<TransactionDto> getAllTransactions();
    List<TransactionDto> getTransactionsByOrderId(Long orderId);
    List<TransactionDto> getTransactionsByUserId(Long userId);
    TransactionDto getTransactionByTransactionNo(String transactionNo);
    List<TransactionDto> getTransactionsByStatus(TransactionStatus status);
     List<SellerTransactionDto>  getTransactionBySellerId(Long sellerId);
}
