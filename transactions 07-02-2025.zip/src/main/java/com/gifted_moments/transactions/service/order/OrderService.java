package com.gifted_moments.transactions.service.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gifted_moments.transactions.dto.OrderDto;
import com.gifted_moments.transactions.entity.Order;
import com.gifted_moments.transactions.entity.OrderItem;
import com.gifted_moments.transactions.entity.User;
import com.gifted_moments.transactions.enums.OrderStatus;
import com.gifted_moments.transactions.repository.OrderItemRepository;
import com.gifted_moments.transactions.repository.OrderRepository;
import com.gifted_moments.transactions.repository.TransactionRepository;
import com.gifted_moments.transactions.repository.UserRepository;
import com.gifted_moments.transactions.request.OrderRequest;
import com.gifted_moments.transactions.request.TransactionRequest;
import com.gifted_moments.transactions.service.transaction.TransactionService;
import com.gifted_moments.transactions.util.Constants;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderService implements IOrderService {
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final UserRepository userRepository;
    private final OrderItemService orderItemService;
    private final TransactionService transactionService;
    private final TransactionRepository transactionRepository;

    @Override
    @Transactional
    public OrderDto createOrder(OrderRequest orderRequest) {
        User user = userRepository.findById(orderRequest.getUserId())
                .orElseThrow(() -> new EntityNotFoundException("User not found"));

        Order order = new Order();
        order.setOrderDate(orderRequest.getOrderDate() != null ? orderRequest.getOrderDate() : LocalDateTime.now());
        order.setShippingAddress(orderRequest.getShippingAddress());
        order.setPaymentMode(orderRequest.getPaymentMode());
        order.setStatus(orderRequest.getStatus());
        order.setUser(user);

        order = orderRepository.save(order);
        Long orderId = order.getOrderId();

        List<OrderItem> orderItems = orderRequest.getOrderItems().stream()
                .map(t -> orderItemService.createOrderItemByOrderId(orderId, t))
                .map(orderItemDto -> orderItemRepository.findById(orderItemDto.getOrderItemId())
                        .orElseThrow(() -> new EntityNotFoundException("Failed to save order item")))
                .toList();
        System.err.println(order.getOrderId());

        BigDecimal totalAmount = orderItems.stream()
                .map(OrderItem::getTotalPrice)
                .filter(totalPrice -> totalPrice != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        order.setTotalAmount(totalAmount);

        order.setOrderItems(orderItems);
        // order = orderRepository.save(order);
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setOrderId(order.getOrderId());
        transactionRequest.setUserId(user.getUserId());
        transactionRequest.setTransactionAmount(order.getTotalAmount());
        transactionRequest.setPaymentMode(order.getPaymentMode());
        transactionService.createTransaction(transactionRequest);
        return OrderDto.fromOrder(order);
    }

    @Override
    @Transactional
    public OrderDto updateOrder(Long orderId, OrderRequest orderRequest) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.ORDER_NOT_FOUND));

        order.setShippingAddress(orderRequest.getShippingAddress());
        order.setStatus(orderRequest.getStatus());

        Order updatedOrder = orderRepository.save(order);
        return OrderDto.fromOrder(updatedOrder);
    }

    @Override
    @Transactional
    public void deleteOrder(Long orderId) {
        if (!orderRepository.existsById(orderId)) {
            throw new EntityNotFoundException(Constants.ORDER_NOT_FOUND);
        }

        transactionRepository.deleteByOrderOrderId(orderId);
        orderRepository.deleteById(orderId);
    }

    @Override
    public List<OrderDto> getAllOrders() {
        return orderRepository.findAll()
                .stream()
                .map(OrderDto::fromOrder)
                .toList();
    }

    @Override
    public OrderDto getOrderById(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new EntityNotFoundException(Constants.ORDER_NOT_FOUND));
        return OrderDto.fromOrder(order);
    }

    @Override
    public List<OrderDto> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserUserId(userId)
                .stream()
                .map(OrderDto::fromOrder)
                .toList();
    }

    @Override
    public List<OrderDto> getOrdersByStatus(OrderStatus status) {
        return orderRepository.findByStatus(status)
                .stream()
                .map(OrderDto::fromOrder)
                .toList();
    }

}
