package com.gifted_moments.transactions.service.order;

import java.util.List;

import com.gifted_moments.transactions.dto.OrderItemDto;
import com.gifted_moments.transactions.request.OrderItemRequest;

public interface IOrderItemService {

    OrderItemDto createOrderItem(OrderItemRequest orderItemRequest);

    OrderItemDto createOrderItemByOrderId(Long orderId, OrderItemRequest orderItemRequest);

    OrderItemDto updateOrderItem(Long orderItemId, OrderItemRequest orderItemRequest);

    void deleteOrderItem(Long orderItemId);

    List<OrderItemDto> getAllOrderItems();

    OrderItemDto getOrderItemById(Long orderItemId);

    List<OrderItemDto> getOrderItemsBySellerProductId(Long sellerProductId);

    List<OrderItemDto> getOrderItemsByProductId(Long productId);

    List<OrderItemDto> getSellerProductsBySellerId(Long sellerId);

}
