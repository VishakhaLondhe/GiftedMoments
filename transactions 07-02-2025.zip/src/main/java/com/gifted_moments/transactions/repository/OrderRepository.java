package com.gifted_moments.transactions.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gifted_moments.transactions.entity.Order;
import com.gifted_moments.transactions.enums.OrderStatus;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserUserId(Long userId);

 
    List<Order> findByStatus(OrderStatus status);
}
