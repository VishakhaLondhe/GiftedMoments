package com.gifted_moments.transactions.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gifted_moments.transactions.entity.Customization;

public interface CustomizationRepository extends JpaRepository<Customization, Long>{

}
