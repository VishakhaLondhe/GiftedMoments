package com.gifted_moments.transactions.dto;

import java.time.LocalDateTime;

import com.gifted_moments.transactions.entity.UserRating;

import lombok.Data;

@Data
public class UserRatingDto {

    private Long ratingId;

    private int rating;
    private String review;
    private LocalDateTime dateTime;

    private UserDto user;
    private Long sellerProductId;

    public static UserRatingDto fromUserRating(UserRating userRating) {
        UserRatingDto dto = new UserRatingDto();
        dto.setRatingId(userRating.getRatingId());
        dto.setRating(userRating.getRating());
        dto.setReview(userRating.getReview());
        dto.setDateTime(userRating.getDateTime());
        dto.setUser(UserDto.fromUser(userRating.getUser()));
        dto.setSellerProductId(userRating.getSellerProduct().getSellerProductId());
        return dto;
    }
}
