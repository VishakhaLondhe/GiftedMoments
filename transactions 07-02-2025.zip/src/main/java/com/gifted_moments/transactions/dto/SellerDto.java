package com.gifted_moments.transactions.dto;

import com.gifted_moments.transactions.entity.Role;
import com.gifted_moments.transactions.entity.Seller;

import lombok.Data;

@Data
public class SellerDto {

    private Long sellerId;

    private String registrationNo;
    private String gstinNo;
    private String shopName;

    private Long userId;
    private String userName;

    private String emailId;
    private String password;
    private String contactNo;
    private String address;

    private Role role;

    public static SellerDto fromSeller(Seller seller) {
    SellerDto sellerDto = new SellerDto();
    sellerDto.setSellerId(seller.getSellerId());
    sellerDto.setRegistrationNo(seller.getRegistrationNo());
    sellerDto.setGstinNo(seller.getGstinNo());
    sellerDto.setShopName(seller.getShopName());
    sellerDto.setUserId(seller.getUser().getUserId());
    sellerDto.setUserName(seller.getUser().getUserName());
    sellerDto.setEmailId(seller.getUser().getEmailId());
    sellerDto.setPassword(seller.getUser().getPassword());
    sellerDto.setContactNo(seller.getUser().getContactNo());
    sellerDto.setAddress(seller.getUser().getAddress());
    sellerDto.setRole(seller.getUser().getRole());
    return sellerDto;
}
}


