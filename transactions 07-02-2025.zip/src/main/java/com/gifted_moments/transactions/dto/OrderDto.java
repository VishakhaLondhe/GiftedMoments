package com.gifted_moments.transactions.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.gifted_moments.transactions.entity.Order;
import com.gifted_moments.transactions.enums.OrderStatus;
import com.gifted_moments.transactions.enums.PaymentMode;

import lombok.Data;

@Data
public class OrderDto {
    private Long orderId;
    private LocalDateTime orderDate;
    private String shippingAddress;
    private BigDecimal totalAmount;
    private PaymentMode paymentMode;
    private OrderStatus status;
    private UserDto user;
    private List<OrderItemDto> orderItems = new ArrayList<>();

    public static OrderDto fromOrder(Order order) {
        OrderDto orderDto = new OrderDto();
        orderDto.setOrderId(order.getOrderId());
        orderDto.setOrderDate(order.getOrderDate());
        orderDto.setShippingAddress(order.getShippingAddress());
        orderDto.setTotalAmount(order.getTotalAmount());
        orderDto.setPaymentMode(order.getPaymentMode());
        orderDto.setStatus(order.getStatus());
        orderDto.setUser(UserDto.fromUser(order.getUser()));
        orderDto.setOrderItems(
                order.getOrderItems().stream().map(OrderItemDto::fromOrderItem).collect(Collectors.toList()));
        return orderDto;
    }
}
