package com.gifted_moments.transactions.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.gifted_moments.transactions.enums.PaymentMode;
import com.gifted_moments.transactions.enums.TransactionStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;
    
    @Column(unique = true)
    private String transactionNo;
    
    @ManyToOne
    @JoinColumn(name = "orderId")
    private Order order;
    
    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;
        
    private LocalDateTime transactionDate;
    private BigDecimal transactionAmount;
    
    @Enumerated(EnumType.STRING)
    private PaymentMode paymentMode;
    
    @Enumerated(EnumType.STRING)
    private TransactionStatus status;
    
    // Getters and setters
}