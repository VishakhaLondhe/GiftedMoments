package com.gifted_moments.transactions.request;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.gifted_moments.transactions.enums.OrderStatus;
import com.gifted_moments.transactions.enums.PaymentMode;

import lombok.Data;

@Data
public class OrderRequest {
    private Long orderId;
    private LocalDateTime orderDate;
    private String shippingAddress;
    private BigDecimal totalAmount;
    private PaymentMode paymentMode;
    private OrderStatus status;
    private Long userId;
    private List<OrderItemRequest> orderItems = new ArrayList<>();
}
