package com.gifted_moments.transactions.request;

import java.math.BigDecimal;
import com.gifted_moments.transactions.enums.PaymentMode;

import lombok.Data;

@Data
public class TransactionRequest {

    private Long orderId;

    private Long userId;


    private BigDecimal transactionAmount;

    private PaymentMode paymentMode;
}
