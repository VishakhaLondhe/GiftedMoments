package com.gifted_moments.transactions.request;

import java.math.BigDecimal;

import com.gifted_moments.transactions.entity.Customization;

import lombok.Data;

@Data
public class OrderItemRequest {

    private Long orderItemId;

    private Long productId;

    private Long sellerProductId;

    private Long orderId;

    private int quantity;
    private BigDecimal price;
    private BigDecimal totalPrice;
    private Customization customization;
}
