package com.gifted_moments.transactions.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gifted_moments.transactions.dto.OrderDto;
import com.gifted_moments.transactions.dto.OrderItemDto;
import com.gifted_moments.transactions.enums.OrderStatus;
import com.gifted_moments.transactions.request.OrderRequest;
import com.gifted_moments.transactions.response.ApiResponse;
import com.gifted_moments.transactions.service.order.IOrderItemService;
import com.gifted_moments.transactions.service.order.IOrderService;
import com.gifted_moments.transactions.util.Constants;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/orders")
public class OrderController {
    private final IOrderService orderService;
    private final IOrderItemService orderItemService;

    @PostMapping
    public ResponseEntity<ApiResponse> createOrder(@RequestBody OrderRequest orderRequest) {
        try {
            OrderDto order = orderService.createOrder(orderRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponse(Constants.SUCCESS, order));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @PutMapping("/{orderId}")
    public ResponseEntity<ApiResponse> updateOrder(@PathVariable Long orderId, @RequestBody OrderRequest orderRequest) {
        try {
            OrderDto order = orderService.updateOrder(orderId, orderRequest);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, order));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity<ApiResponse> deleteOrder(@PathVariable Long orderId) {
        try {
            orderService.deleteOrder(orderId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Order deleted successfully"));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllOrders() {
        try {
            List<OrderDto> orders = orderService.getAllOrders();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, orders));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<ApiResponse> getOrderById(@PathVariable Long orderId) {
        try {
            OrderDto order = orderService.getOrderById(orderId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, order));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse> getOrdersByUserId(@PathVariable Long userId) {
        try {
            List<OrderDto> orders = orderService.getOrdersByUserId(userId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, orders));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse> getOrdersByStatus(@PathVariable OrderStatus status) {
        try {
            List<OrderDto> orders = orderService.getOrdersByStatus(status);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, orders));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    


    @GetMapping("/items/{orderItemId}")
    public ResponseEntity<ApiResponse> getOrderItemById(@PathVariable Long orderItemId) {
        try {
            OrderItemDto orderItem = orderItemService.getOrderItemById(orderItemId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, orderItem));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/items/seller-product/{sellerProductId}")
    public ResponseEntity<ApiResponse> getOrderItemsBySellerProductId(@PathVariable Long sellerProductId) {
        try {
            List<OrderItemDto> orderItems = orderItemService.getOrderItemsBySellerProductId(sellerProductId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, orderItems));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/items/product/{productId}")
    public ResponseEntity<ApiResponse> getOrderItemsByProductId(@PathVariable Long productId) {
        try {
            List<OrderItemDto> orderItems = orderItemService.getOrderItemsByProductId(productId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, orderItems));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/items/seller/{sellerId}")
    public ResponseEntity<ApiResponse> getSellerProductsBySellerId(@PathVariable Long sellerId) {
        try {
            List<OrderItemDto> sellerProducts = orderItemService.getSellerProductsBySellerId(sellerId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, sellerProducts));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }
}
