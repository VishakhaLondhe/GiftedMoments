package com.gifted_moments.transactions.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gifted_moments.transactions.dto.SellerTransactionDto;
import com.gifted_moments.transactions.dto.TransactionDto;
import com.gifted_moments.transactions.enums.TransactionStatus;
import com.gifted_moments.transactions.response.ApiResponse;
import com.gifted_moments.transactions.service.transaction.ITransactionService;
import com.gifted_moments.transactions.util.Constants;

import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@RestController
@RequestMapping("/transactions")
public class TransactionController {
    private final ITransactionService transactionService;

    @GetMapping("/{transactionId}")
    public ResponseEntity<ApiResponse> getTransactionById(@PathVariable Long transactionId) {
        try {
            TransactionDto transaction = transactionService.getTransactionById(transactionId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, transaction));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllTransactions() {
        try {
            List<TransactionDto> transactions = transactionService.getAllTransactions();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, transactions));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }
    @GetMapping("/order/{orderId}")
    public ResponseEntity<ApiResponse> getTransactionsByOrderId(@PathVariable Long orderId) {
        try {
            List<TransactionDto> transactions = transactionService.getTransactionsByOrderId(orderId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, transactions));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse> getTransactionsByUserId(@PathVariable Long userId) {
        try {
            List<TransactionDto> transactions = transactionService.getTransactionsByUserId(userId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, transactions));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }
    @GetMapping("/seller/{sellerId}")
    public ResponseEntity<ApiResponse> getTransactionsBySellerId(@PathVariable Long sellerId) {
        try {
            List<SellerTransactionDto> transactions = transactionService.getTransactionBySellerId(sellerId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, transactions));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

   @GetMapping("/transaction-no/{transactionNo}")
    public ResponseEntity<ApiResponse> getTransactionByTransactionNo(@PathVariable String transactionNo) {
        try {
            TransactionDto transaction = transactionService.getTransactionByTransactionNo(transactionNo);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, transaction));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse> getTransactionsByStatus(@PathVariable TransactionStatus status) {
        try {
            List<TransactionDto> transactions = transactionService.getTransactionsByStatus(status);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, transactions));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }
}
