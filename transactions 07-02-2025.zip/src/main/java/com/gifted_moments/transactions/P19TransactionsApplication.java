package com.gifted_moments.transactions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P19TransactionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(P19TransactionsApplication.class, args);
	}

}
