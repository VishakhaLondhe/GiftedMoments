package com.gifted_moments.transactions.util;


public class Constants {
      private Constants() {
            throw new IllegalStateException("Utility class");
      }

      public static final String SUCCESS = "success";
      public static final String FAILED = "failed";
      public static final String ERROR = "error";
      public static final String NOT_FOUND = "Entity Not Found";

      public static final String SELLER_PRODUCT_NOT_FOUND = "SellerProduct not found";
      public static final String USER_RATING_NOT_FOUND = "User Rating not found";
      public static final String TRANSACTION_NOT_FOUND = "Transaction not found";
      public static final String USER_NOT_FOUND = "User not found";
      public static final String ORDER_ITEM_NOT_FOUND = "Order Item not found";
      public static final String ORDER_NOT_FOUND = "Order not found";

      

}
