package com.gifted_moments.transactions.exception;

public class ResourceInvalidException extends RuntimeException {
    public ResourceInvalidException(String message){
        super(message);
    }
}