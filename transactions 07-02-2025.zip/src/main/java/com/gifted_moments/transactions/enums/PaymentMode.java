package com.gifted_moments.transactions.enums;

public enum PaymentMode {
    CASH,
    CARD,
    NET_BANKING,
    COD,
    UPI
}
