package com.gifted_moments.transactions.enums;

public enum TransactionStatus {
    PENDING,
    FAILED,
    COMPLETED
}
