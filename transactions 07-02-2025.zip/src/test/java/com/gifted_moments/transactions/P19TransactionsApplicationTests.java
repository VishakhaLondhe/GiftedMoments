package com.gifted_moments.transactions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P19TransactionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
