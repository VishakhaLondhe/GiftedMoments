package com.gifted_moments.api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P19ApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
